const ROUTER_URL = "https://alfred-router-prod-production.up.railway.app";
let polling = false;
let pollInterval = null;

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "start") startPolling(msg.token);
  if (msg.action === "stop") stopPolling();
});

// Auto-start on browser launch
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(["connected", "bridgeToken"], (data) => {
    if (data.connected && data.bridgeToken) {
      startPolling(data.bridgeToken);
    }
  });
});

// Also auto-start on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(["connected", "bridgeToken"], (data) => {
    if (data.connected && data.bridgeToken) {
      startPolling(data.bridgeToken);
    }
  });
});

function startPolling(token) {
  if (polling) return;
  polling = true;
  console.log("[Alfred Bridge] Started polling for commands");

  // Register
  fetch(`${ROUTER_URL}/bridge/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token }),
  }).catch(() => {});

  pollInterval = setInterval(() => pollForCommand(token), 3000);
}

function stopPolling() {
  polling = false;
  if (pollInterval) clearInterval(pollInterval);
  console.log("[Alfred Bridge] Stopped");
}

async function pollForCommand(token) {
  try {
    const resp = await fetch(`${ROUTER_URL}/bridge/poll?token=${token}`);
    const data = await resp.json();
    if (data && data.action) {
      console.log("[Alfred Bridge] Command:", data.action);
      const result = await executeCommand(data);
      // Send result back
      await fetch(`${ROUTER_URL}/bridge/result`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, id: data.id, result }),
      });
      // Increment counter
      chrome.storage.local.get(["cmdCount"], (stored) => {
        chrome.storage.local.set({ cmdCount: (stored.cmdCount || 0) + 1 });
      });
    }
  } catch {}
}

async function executeCommand(cmd) {
  const { action, params } = cmd;

  try {
    switch (action) {
      case "navigate": {
        const tab = await chrome.tabs.create({ url: params.url, active: false });
        // Wait for page to load
        await new Promise(r => setTimeout(r, 5000));
        // Extract page content
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => ({
            title: document.title,
            text: document.body?.innerText?.substring(0, 5000) || "",
            url: window.location.href,
          }),
        });
        return { ok: true, ...results[0]?.result };
      }

      case "search": {
        const query = encodeURIComponent(params.query);
        const tab = await chrome.tabs.create({ url: `https://www.google.com/search?q=${query}`, active: false });
        await new Promise(r => setTimeout(r, 4000));
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            const items = document.querySelectorAll(".g");
            return Array.from(items).slice(0, 10).map(el => ({
              title: el.querySelector("h3")?.textContent || "",
              url: el.querySelector("a")?.href || "",
              snippet: el.querySelector(".VwiC3b")?.textContent || "",
            })).filter(r => r.title && r.url);
          },
        });
        return { ok: true, results: results[0]?.result || [], count: results[0]?.result?.length || 0 };
      }

      case "extract": {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0]) return { ok: false, error: "No active tab" };
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: (selector) => {
            const els = document.querySelectorAll(selector || "body");
            return Array.from(els).slice(0, 50).map(el => el.innerText?.trim()?.substring(0, 200)).filter(Boolean);
          },
          args: [params.selector || "body"],
        });
        return { ok: true, elements: results[0]?.result || [] };
      }

      case "get_page_contacts": {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tabs[0]) return { ok: false, error: "No active tab" };
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: () => {
            const text = document.body.innerText;
            const phones = text.match(/(\+?56\s?\d[\s.-]?\d{4}[\s.-]?\d{4})/g) || [];
            const emails = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g) || [];
            const whatsapp = Array.from(document.querySelectorAll('a[href*="wa.me"], a[href*="whatsapp"]')).map(a => a.href);
            return { phones: [...new Set(phones)], emails: [...new Set(emails)], whatsapp: [...new Set(whatsapp)] };
          },
        });
        return { ok: true, contacts: results[0]?.result };
      }

      default:
        return { ok: false, error: `Unknown action: ${action}` };
    }
  } catch (e) {
    return { ok: false, error: e.message };
  }
}
