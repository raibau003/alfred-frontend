const ROUTER_URL = "https://alfred-router-prod-production.up.railway.app";

async function connect() {
  const token = document.getElementById("token").value.trim();
  if (!token) return;

  const btn = document.getElementById("connectBtn");
  const errorEl = document.getElementById("error");
  btn.disabled = true;
  btn.textContent = "Conectando...";
  errorEl.textContent = "";

  try {
    const resp = await fetch(`${ROUTER_URL}/bridge/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token }),
    });

    if (!resp.ok) {
      errorEl.textContent = `Error HTTP ${resp.status}`;
      btn.textContent = "Conectar";
      btn.disabled = false;
      return;
    }

    const data = await resp.json();

    if (data.ok) {
      // Save and start
      await chrome.storage.local.set({ bridgeToken: token, connected: true, cmdCount: 0 });
      chrome.runtime.sendMessage({ action: "start", token });
      updateUI(true, 0);
    } else {
      errorEl.textContent = data.error || "Error desconocido";
      btn.textContent = "Conectar";
      btn.disabled = false;
    }
  } catch (e) {
    errorEl.textContent = e.message || "No se pudo conectar";
    btn.textContent = "Conectar";
    btn.disabled = false;
  }
}

function disconnect() {
  chrome.storage.local.set({ connected: false, bridgeToken: "" });
  chrome.runtime.sendMessage({ action: "stop" });
  updateUI(false, 0);
}

function updateUI(connected, cmdCount) {
  const statusEl = document.getElementById("status");
  const textEl = statusEl.querySelector(".text");
  const setupEl = document.getElementById("setup");
  const connectedEl = document.getElementById("connected");
  const cmdCountEl = document.getElementById("cmdCount");

  if (connected) {
    statusEl.className = "status connected";
    textEl.textContent = "Conectado";
    setupEl.style.display = "none";
    connectedEl.style.display = "block";
    cmdCountEl.textContent = cmdCount || 0;
  } else {
    statusEl.className = "status disconnected";
    textEl.textContent = "Desconectado";
    setupEl.style.display = "block";
    connectedEl.style.display = "none";
  }
}

// Load state on popup open
chrome.storage.local.get(["connected", "bridgeToken", "cmdCount"], (data) => {
  if (data.connected && data.bridgeToken) {
    document.getElementById("token").value = data.bridgeToken;
    updateUI(true, data.cmdCount || 0);
  }
});
